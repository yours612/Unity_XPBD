import json
import os
import glob

def merge_json_files(json_file_paths, output_file_path):
    # 初始化一个空数组来存储所有合并后的数据
    all_data = []

    for file_path in json_file_paths:
        with open(file_path, 'r') as file:
            # 读取并解析每个 JSON 文件的内容
            data = json.load(file)
            # 将解析出的数据添加到数组中
            all_data.append(data)

    # 将合并后的 JSON 数据写入到输出文件中
    with open(output_file_path, 'w') as output_file:
        json.dump(all_data, output_file, indent=4)

def merge_json_files1(json_file_paths, output_file_path):
    all_data = []

    for file_path in json_file_paths:
        try:
            with open(file_path, 'r') as file:
                data = json.load(file)  # 尝试解析 JSON
                all_data.append(data)
        except json.JSONDecodeError as e:
            print(f"Error decoding {file_path}: {e}")
            continue  # 跳过有问题的文件

    with open(output_file_path, 'w') as output_file:
        json.dump(all_data, output_file, indent=4)

# 获取所有JSON文件的路径
json_files = glob.glob('E:\\Unity\\data\\c\\*.json')

# 指定输出文件的路径
output_file_path = 'E:\\Unity\\data\\c\\dataset_onlycollision.json'


# 合并JSON文件
merge_json_files1(json_files, output_file_path)