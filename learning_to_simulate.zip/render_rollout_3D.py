import time  # Import time module
import pickle

from absl import app
from absl import flags

from matplotlib import animation
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # 导入3D坐标轴支持
import numpy as np
import matplotlib.colors as mcolors
from sklearn.metrics import mean_squared_error

# 0 1

#output\\lunwen\\rollout\\no_all\\rollout_test_0.pkl
#output\\myTest_PBD\\dannang\\all\\testData\\rnn\\rollout_test_4.pkl
flags.DEFINE_string("rollout_path", 'output\\lunwen\\allforce\\4m\\rollout_test_3.pkl', help="Path to rollout pickle file")
flags.DEFINE_integer("step_stride", 3, help="Stride of steps to skip.")
flags.DEFINE_boolean("block_on_show", True, help="For test purposes.")

FLAGS = flags.FLAGS

TYPE_TO_COLOR = {
    3: "black",  # Boundary particles.
    0: "green",  # Rigid solids.
    7: "magenta",  # Goop.
    6: "gold",  # Sand.
    5: "blue",  # Water.
    1: "red", # mySoft
}

def main(unused_argv):
    if not FLAGS.rollout_path:
        raise ValueError("A `rollout_path` must be passed.")
    with open(FLAGS.rollout_path, "rb") as file:
        rollout_data = pickle.load(file)

    vertex_positions = []

    fig = plt.figure(figsize=(10, 7))
    ax1 = fig.add_subplot(121, projection='3d')
    ax2 = fig.add_subplot(122, projection='3d')

    plot_info = []
    for ax_i, (ax, label, rollout_field) in enumerate(
        [(ax1, "Ground truth", "ground_truth_rollout"),
         (ax2, "Prediction", "predicted_rollout")]):
        ax.set_title(label)
        bounds = rollout_data["metadata"]["bounds"]
        ax.set_xlim(bounds[0][0], bounds[0][1])
        ax.set_ylim(bounds[1][0], bounds[1][1])
        ax.set_zlim(bounds[2][0], bounds[2][1])
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_zticks([])
        points = {
            particle_type: ax.scatter([], [], [], s=2, color=color)
            for particle_type, color in TYPE_TO_COLOR.items()}
        trajectory = np.concatenate([
            rollout_data["initial_positions"],
            rollout_data[rollout_field]], axis=0)
        plot_info.append((ax, trajectory, points))

    num_steps = trajectory.shape[0]

    def update(step_i):
        frame_start_time = time.time()  # Start time for this frame

        outputs = []
        ground_truth_positions = []
        predicted_positions = []
        for _, trajectory, points in plot_info:
            for particle_type, scatter in points.items():
                mask = rollout_data["particle_types"] == particle_type
                scatter._offsets3d = (trajectory[step_i, mask, 0],
                                      trajectory[step_i, mask, 2],
                                      trajectory[step_i, mask, 1])
                outputs.append(scatter)
                if step_i == 0:
                    vertex_positions.append(trajectory[step_i, 0, :])  # Store position of vertex index 0
                else:
                    vertex_positions.append(trajectory[step_i, 0, :])  # Continue to append positions

        frame_end_time = time.time()  # End time for this frame

        return outputs



    unused_animation = animation.FuncAnimation(
        fig, update,
        frames=np.arange(0, num_steps, FLAGS.step_stride), interval=10)
    #
    plt.show(block=FLAGS.block_on_show)

    # Print the positions of vertex index 0
    # print("Positions of vertex index 0 at each timestep:")
    # for pos in vertex_positions:
    #     print(pos)

if __name__ == "__main__":
    app.run(main)
