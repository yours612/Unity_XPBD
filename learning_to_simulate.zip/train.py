# pylint: disable=g-bad-file-header
# Copyright 2020 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or  implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
# pylint: disable=line-too-long
"""Training script for https://arxiv.org/pdf/2002.09405.pdf.

Example usage (from parent directory):
`python -m learning_to_simulate.train --data_path={DATA_PATH} --model_path={MODEL_PATH}`

Evaluate model from checkpoint (from parent directory):
`python -m learning_to_simulate.train --data_path={DATA_PATH} --model_path={MODEL_PATH} --mode=eval`

Produce rollouts (from parent directory):
`python -m learning_to_simulate.train --data_path={DATA_PATH} --model_path={MODEL_PATH} --output_path={OUTPUT_PATH} --mode=eval_rollout`


"""
# pylint: enable=line-too-long
import collections
import functools
import json
import os
import pickle
import time

from absl import app
from absl import flags
from absl import logging
import numpy as np
#import tensorflow.compat.v1 as tf
import tensorflow as tf
#from tensorflow.compat.v1 import estimator as tf_estimator
from tensorflow import estimator as tf_estimator
import tree


from learning_to_simulate import learned_simulator
from learning_to_simulate import noise_utils
from learning_to_simulate import reading_utils

import matplotlib.pyplot as plt


flags.DEFINE_enum(
    'mode', 'eval_rollout', ['train', 'eval', 'eval_rollout'],
    help='Train model, one step evaluation or rollout evaluation.')
flags.DEFINE_enum('eval_split', 'test', ['train', 'valid', 'test'],
                  help='Split to use when running evaluation.')
flags.DEFINE_string('data_path', 'data\\lunwen\\allforce', help='The dataset directory.')
flags.DEFINE_integer('batch_size', 1, help='The batch size.')
flags.DEFINE_integer('num_steps', int(60e4), help='Number of steps of training.')
flags.DEFINE_float('noise_std', 6.7e-5, help='The std deviation of the noise.')
flags.DEFINE_string('model_path', 'model\\lunwen\\no_all',
                    #model\\myTest_PBD\\dannang\\all\\newData_1m
                    help=('The path for saving checkpoints of the model. '
                          'Defaults to a temporary directory.'))
flags.DEFINE_string('output_path', 'output\\lunwen\\allforce\\no_all',
                    help='The path for saving outputs (e.g. rollouts).')


FLAGS = flags.FLAGS

Stats = collections.namedtuple('Stats', ['mean', 'std'])

INPUT_SEQUENCE_LENGTH = 4  # So we can calculate the last 5 velocities.
NUM_PARTICLE_TYPES = 1
KINEMATIC_PARTICLE_ID = 3 ## 障碍物

Message_passing_steps = 4

# 根据粒子类型标识动力学粒子（如障碍物,边界--不可动的粒子）
def get_kinematic_mask(particle_types):
  """Returns a boolean mask, set to true for kinematic (obstacle) particles."""
  return tf.equal(particle_types, KINEMATIC_PARTICLE_ID)

# 准备训练数据，从完整的轨迹数据中计算目标和输入特征，包括位置和全局上下文。
def prepare_inputs(tensor_dict):
  """Prepares a single stack of inputs by calculating inputs and targets.

  Computes n_particles_per_example, which is a tensor that contains information
  about how to partition the axis - i.e. which nodes belong to which graph.

  Adds a batch axis to `n_particles_per_example` and `step_context` so they can
  later be batched using `batch_concat`. This batch will be the same as if the
  elements had been batched via stacking.

  Note that all other tensors have a variable size particle axis,
  and in this case they will simply be concatenated along that
  axis.



  Args:
    tensor_dict: A dict of tensors containing positions, and step context (
    if available).

  Returns:
    A tuple of input features and target positions.

  """
  # Position is encoded as [sequence_length, num_particles, dim] but the model
  # expects [num_particles, sequence_length, dim].
  pos = tensor_dict['position']
  pos = tf.transpose(pos, perm=[1, 0, 2])

  # The target position is the final step of the stack of positions.
  target_position = pos[:, -1]

  # Remove the target from the input.
  tensor_dict['position'] = pos[:, :-1]

  if 'force' in tensor_dict:
      force = tensor_dict['force']
      force = tf.transpose(force, perm=[1, 0, 2])
      tensor_dict['force'] = force[:, :-1]

  # Compute the number of particles per example.
  num_particles = tf.shape(pos)[0]
  # Add an extra dimension for stacking via concat.
  tensor_dict['n_particles_per_example'] = num_particles[tf.newaxis]

  if 'step_context' in tensor_dict:
    # Take the input global context. We have a stack of global contexts,
    # and we take the penultimate since the final is the target.
    tensor_dict['step_context'] = tensor_dict['step_context'][-2]
    # Add an extra dimension for stacking via concat.
    tensor_dict['step_context'] = tensor_dict['step_context'][tf.newaxis]
  return tensor_dict, target_position
#  为模拟轨迹滚动输出准备输入数据
def prepare_rollout_inputs(context, features):
  """Prepares an inputs trajectory for rollout."""
  out_dict = {**context}
  # Position is encoded as [sequence_length, num_particles, dim] but the model
  # expects [num_particles, sequence_length, dim].
  pos = tf.transpose(features['position'], [1, 0, 2])
  # The target position is the final step of the stack of positions.
  target_position = pos[:, -1]
  # Remove the target from the input.
  out_dict['position'] = pos[:, :-1]

  if 'force' in features:
      force = features['force']
      force = tf.transpose(force, perm=[1, 0, 2])
      #out_dict['force'] = force[:, :-1]
      out_dict['force'] = force[:, :-1]

  # Compute the number of nodes
  out_dict['n_particles_per_example'] = [tf.shape(pos)[0]]
  if 'step_context' in features:
    out_dict['step_context'] = features['step_context']
  out_dict['is_trajectory'] = tf.constant([True], tf.bool)
  return out_dict, target_position

def batch_concat(dataset, batch_size):
  """We implement batching as concatenating on the leading axis."""

  # We create a dataset of datasets of length batch_size.
  windowed_ds = dataset.window(batch_size)

  # The plan is then to reduce every nested dataset by concatenating. We can
  # do this using tf.data.Dataset.reduce. This requires an initial state, and
  # then incrementally reduces by running through the dataset

  # Get initial state. In this case this will be empty tensors of the
  # correct shape.
  initial_state = tree.map_structure(
      lambda spec: tf.zeros(  # pylint: disable=g-long-lambda
          shape=[0] + spec.shape.as_list()[1:], dtype=spec.dtype),
      dataset.element_spec)

  # We run through the nest and concatenate each entry with the previous state.
  def reduce_window(initial_state, ds):
    return ds.reduce(initial_state, lambda x, y: tf.concat([x, y], axis=0))

  return windowed_ds.map(
      lambda *x: tree.map_structure(reduce_window, initial_state, x))

def get_input_fn(data_path, batch_size, mode, split):
  """Gets the learning simulation input function for tf.estimator.Estimator.

  Args:
    data_path: the path to the dataset directory.
    batch_size: the number of graphs in a batch.
    mode: either 'one_step_train', 'one_step' or 'rollout'
    split: either 'train', 'valid' or 'test.

  Returns:
    The input function for the learning simulation model.
  """
  def input_fn():
    """Input function for learning simulation."""
    # Loads the metadata of the dataset.
    metadata = _read_metadata(data_path)
    # Create a tf.data.Dataset from the TFRecord.
    ds = tf.data.TFRecordDataset([os.path.join(data_path, f'{split}.tfrecord')])
    ds = ds.map(functools.partial(
        reading_utils.parse_serialized_simulation_example, metadata=metadata))
    if mode.startswith('one_step'):
      # Splits an entire trajectory into chunks of 7 steps.
      # Previous 5 velocities, current velocity and target.
      split_with_window = functools.partial(
          reading_utils.split_trajectory,
          window_length=INPUT_SEQUENCE_LENGTH + 1)
      ds = ds.flat_map(split_with_window)
      # Splits a chunk into input steps and target steps
      ds = ds.map(prepare_inputs)
      # If in train mode, repeat dataset forever and shuffle.
      if mode == 'one_step_train':
        ds = ds.repeat() #复制
        ds = ds.shuffle(2000) #打乱
      # Custom batching on the leading axis.
      ds = batch_concat(ds, batch_size)
    elif mode == 'rollout':
      # Rollout evaluation only available for batch size 1
      assert batch_size == 1
      ds = ds.map(prepare_rollout_inputs)
    else:
      raise ValueError(f'mode: {mode} not recognized')
    return ds

  return input_fn


def rollout(simulator, features, num_steps):
  """Rolls out a trajectory by applying the model in sequence."""
  forces = features['force']
  f_points = features['f_point']
  initial_positions = features['position'][:, 0:INPUT_SEQUENCE_LENGTH]
  ground_truth_positions = features['position'][:, INPUT_SEQUENCE_LENGTH:]
  global_context = features.get('step_context')
  def step_fn(step, forces, current_positions, predictions):
    if global_context is None:
      global_context_step = None
    else:
      global_context_step = global_context[
          step + INPUT_SEQUENCE_LENGTH - 1][tf.newaxis]

    start_index = step
    cur_forces = tf.slice(forces, [0, start_index, 0], [-1, INPUT_SEQUENCE_LENGTH, 3])

    # _build 是 Sonnet 模块的默认方法，当你调用一个 Sonnet 模块的实例时
    # （比如 simulator 对象），实际上就是在调用该模块的 _build 方法。这是 Sonnet 模块的设计约定。
    next_position = simulator(
        cur_forces,
        f_points,
        current_positions,
        n_particles_per_example=features['n_particles_per_example'],
        particle_types=features['particle_type'],
        global_context=global_context_step)

    # Update kinematic particles from prescribed trajectory.
    kinematic_mask = get_kinematic_mask(features['particle_type'])
    next_position_ground_truth = ground_truth_positions[:, step]
    next_position = tf.where(kinematic_mask, next_position_ground_truth,
                             next_position)

    updated_predictions = predictions.write(step, next_position)

    # Shift `current_positions`, removing the oldest position in the sequence
    # and appending the next position at the end.
    next_positions = tf.concat([current_positions[:, 1:],
                                next_position[:, tf.newaxis]], axis=1)

    return (step + 1, forces, next_positions, updated_predictions)

  predictions = tf.TensorArray(size=num_steps, dtype=tf.float32)
  _, _, _, predictions = tf.while_loop(
      cond=lambda step, force, state, prediction: tf.less(step, num_steps),
      body=step_fn,
      loop_vars=(0, forces, initial_positions, predictions),
      back_prop=False,
      parallel_iterations=1)

  output_dict = {
      'forces': tf.transpose(forces, [1, 0, 2]),
      'initial_positions': tf.transpose(initial_positions, [1, 0, 2]),
      'predicted_rollout': predictions.stack(),
      'ground_truth_rollout': tf.transpose(ground_truth_positions, [1, 0, 2]),
      'particle_types': features['particle_type'],
  }

  if global_context is not None:
    output_dict['global_context'] = global_context
  return output_dict


def _combine_std(std_x, std_y):
  return np.sqrt(std_x**2 + std_y**2)


def _get_simulator(model_kwargs, metadata, acc_noise_std, vel_noise_std):
  """Instantiates the simulator."""
  # Cast statistics to numpy so they are arrays when entering the model.
  cast = lambda v: np.array(v, dtype=np.float32)
  acceleration_stats = Stats(
      cast(metadata['acc_mean']),
      _combine_std(cast(metadata['acc_std']), acc_noise_std))
  velocity_stats = Stats(
      cast(metadata['vel_mean']),
      _combine_std(cast(metadata['vel_std']), vel_noise_std))
  normalization_stats = {'acceleration': acceleration_stats,
                         'velocity': velocity_stats}
  if 'context_mean' in metadata:
    context_stats = Stats(
        cast(metadata['context_mean']), cast(metadata['context_std']))
    normalization_stats['context'] = context_stats

  simulator = learned_simulator.LearnedSimulator(
      num_dimensions=metadata['dim'],
      connectivity_radius=metadata['default_connectivity_radius'],
      graph_network_kwargs=model_kwargs,
      boundaries=metadata['bounds'],
      num_particle_types=NUM_PARTICLE_TYPES,
      normalization_stats=normalization_stats,
      particle_type_embedding_size=16)
  return simulator

def get_one_step_estimator_fn(data_path,
                              noise_std,
                              latent_size=128,
                              hidden_size=128,
                              hidden_layers=2,
                              message_passing_steps=Message_passing_steps):
  """Gets one step model for training simulation."""
  metadata = _read_metadata(data_path)

  model_kwargs = dict(
      latent_size=latent_size,
      mlp_hidden_size=hidden_size,
      mlp_num_hidden_layers=hidden_layers,
      num_message_passing_steps=message_passing_steps)

  def estimator_fn(features, labels, mode): # labels:实际的目标值，本例中是粒子的下一个位置
    # 定义 TensorBoard 日志目录
    log_dir = 'output\\logs'
    #writer = tf.summary.FileWriter(log_dir)


    target_next_position = labels
    simulator = _get_simulator(model_kwargs, metadata,
                               vel_noise_std=noise_std,
                               acc_noise_std=noise_std)
    # Sample the noise to add to the inputs to the model during training.
    sampled_noise = noise_utils.get_random_walk_noise_for_position_sequence(
        features['position'], noise_std_last_step=noise_std)
    # tf.logical_not: 对 get_kinematic_mask 的结果取反，得到非动力学粒子的掩码
    non_kinematic_mask = tf.logical_not(
        get_kinematic_mask(features['particle_type']))
    # 对噪声应用掩码，确保只有非动力学粒子（可移动粒子）被添加噪声。
    noise_mask = tf.cast(
        non_kinematic_mask, sampled_noise.dtype)[:, tf.newaxis, tf.newaxis]
    sampled_noise *= noise_mask

    # Get the predictions and target accelerations.
    # 使用模拟器计算预测的和目标加速度。这是通过将当前和下一位置（带有噪声）的粒子数据提供给模拟器来完成的。
    pred_target = simulator.get_predicted_and_target_normalized_accelerations(
        next_position=target_next_position,

        force_sequence=features['force'],
        f_points = features['f_point'],

        position_sequence=features['position'],
        position_sequence_noise=sampled_noise,
        n_particles_per_example=features['n_particles_per_example'],
        particle_types=features['particle_type'],
        global_context=features.get('step_context'))
    # 解包 pred_target 来获取预测加速度和目标加速度。
    pred_acceleration, target_acceleration = pred_target

    # Calculate the loss and mask out loss on kinematic particles/
    loss_acc = abs(pred_acceleration - target_acceleration)
    #loss_acc = tf.reduce_sum(loss_acc)

    # 只计算非动力学粒子的损失，动力学粒子的损失被设为零。
    num_non_kinematic = tf.reduce_sum(
        tf.cast(non_kinematic_mask, tf.float32))
    loss_acc = tf.where(non_kinematic_mask, loss_acc, tf.zeros_like(loss_acc))
    loss_acc = tf.reduce_sum(loss_acc) / tf.reduce_sum(num_non_kinematic)

    # Calculate next position and add some additional eval metrics (only eval).
    predicted_next_position = simulator(
        force_sequence=features['force'],
        f_points=features['f_point'],
        position_sequence=features['position'],
        n_particles_per_example=features['n_particles_per_example'],
        particle_types=features['particle_type'],
        global_context=features.get('step_context'))

    # pos_RMSE = tf.sqrt(tf.reduce_mean(tf.square(target_next_position - predicted_next_position)))
    # volume_RMSE = tf.sqrt(tf.reduce_mean(tf.square(compute_volume(target_next_position) - compute_volume(predicted_next_position))))
    # print("Position RMSE:", pos_RMSE.numpy())
    # print("Position RMSE:", volume_RMSE.numpy())
    # E_RMSE = tf.sqrt(tf.reduce_mean(tf.square(target_next_position - predicted_next_position)))

    current_f_point = features['f_point']
    target_f_point_positions = tf.gather_nd(target_next_position, tf.expand_dims(current_f_point, axis=-1))
    predicted_f_point_positions = tf.gather_nd(predicted_next_position, tf.expand_dims(current_f_point, axis=-1))
    # loss_f_point = tf.reduce_mean(tf.norm(target_f_point_positions - predicted_f_point_positions, axis=-1))
    # loss_f_point = tf.reduce_sum(loss_f_point)
    loss_f_point = tf.norm(target_f_point_positions - predicted_f_point_positions)

    #loss_Volume = abs(compute_volume(target_next_position) - compute_volume(predicted_next_position))
    # loss = loss_acc*0.5+loss_Volume*0.5
    loss = loss_acc #+ loss_f_point

    # 只计算非动力学粒子的损失，动力学粒子的损失被设为零。
    #num_non_kinematic = tf.reduce_sum(
    #    tf.cast(non_kinematic_mask, tf.float32))
    #loss = tf.where(non_kinematic_mask, loss, tf.zeros_like(loss))
    #loss = tf.reduce_sum(loss) / tf.reduce_sum(num_non_kinematic)

    global_step = tf.train.get_global_step()
    # Set learning rate to decay from 1e-4 to 1e-6 exponentially.
    min_lr = 1e-5
    lr = tf.train.exponential_decay(learning_rate=1e-4 - min_lr,
                                    global_step=global_step,
                                    decay_steps=int(30e4),
                                    decay_rate=0.1) + min_lr
    opt = tf.train.AdamOptimizer(learning_rate=lr)
    train_op = opt.minimize(loss, global_step)

    # summary_acc = tf.summary.scalar("loss_acc", loss_acc)
    # #summary_f_point = tf.summary.scalar("loss_f_point", loss_f_point)
    # summary_total_loss = tf.summary.scalar("total_loss", loss)
    # #summary_op = tf.summary.merge([summary_acc, summary_f_point, summary_total_loss])
    # summary_hook = tf.train.SummarySaverHook(
    #     save_steps=100,  # 每 100 步保存一次
    #     output_dir=log_dir,
    #     summary_op=summary_acc
    # )


    # 设置预测输出和评估指标
    predictions = {'predicted_next_position': predicted_next_position}
    eval_metrics_ops = {
        'loss_mse': tf.metrics.mean_squared_error(
            pred_acceleration, target_acceleration),
        'one_step_position_mse': tf.metrics.mean_squared_error(
            predicted_next_position, target_next_position)
    }
    return tf_estimator.EstimatorSpec(
        mode=mode,
        train_op=train_op,
        loss=loss,
        predictions=predictions,
        eval_metric_ops=eval_metrics_ops,
        #training_hooks = [summary_hook]  # 添加 Hook
    )

  return estimator_fn


def get_rollout_estimator_fn(data_path,
                             noise_std,
                             latent_size=128,
                             hidden_size=128,
                             hidden_layers=2,
                             message_passing_steps=Message_passing_steps):
  """Gets the model function for tf.estimator.Estimator."""
  metadata = _read_metadata(data_path)

  model_kwargs = dict(
      latent_size=latent_size,
      mlp_hidden_size=hidden_size,
      mlp_num_hidden_layers=hidden_layers,
      num_message_passing_steps=message_passing_steps)

  def estimator_fn(features, labels, mode):
    del labels  # Labels to conform to estimator spec.
    simulator = _get_simulator(model_kwargs, metadata,
                               acc_noise_std=noise_std,
                               vel_noise_std=noise_std)

    num_steps = metadata['sequence_length'] - INPUT_SEQUENCE_LENGTH
    rollout_op = rollout(simulator, features, num_steps=num_steps)
    squared_error = abs(rollout_op['predicted_rollout'] -
                     rollout_op['ground_truth_rollout'])
    loss = tf.reduce_mean(squared_error)
    eval_ops = {'rollout_error_mse': tf.metrics.mean_squared_error(
        rollout_op['predicted_rollout'], rollout_op['ground_truth_rollout'])}

    # Add a leading axis, since Estimator's predict method insists that all
    # tensors have a shared leading batch axis fo the same dims.
    rollout_op = tree.map_structure(lambda x: x[tf.newaxis], rollout_op)
    return tf_estimator.EstimatorSpec(
        mode=mode,
        train_op=None,
        loss=loss,
        predictions=rollout_op,
        eval_metric_ops=eval_ops)

  return estimator_fn


def _read_metadata(data_path):
  with open(os.path.join(data_path, 'metadata.json'), 'rt') as fp:
    return json.loads(fp.read())

class LoggingHook(tf.estimator.SessionRunHook):
    def __init__(self):
        self.loss_history = []

    def before_run(self, run_context):
        # 请求损失张量
        return tf.estimator.SessionRunArgs({'loss': run_context.session.graph.get_tensor_by_name('loss:0')})

    def after_run(self, run_context, run_values):
        # 获取并存储损失值
        self.loss_history.append(run_values.results['loss'])


def compute_volume(vertices):
    faces = [[381,210,361],
[79,217,247],
[189,356,295],
[237,0,42],
[19,29,190],
[6,88,155],
[1,272,43],
[175,195,95],
[168,366,2],
[177,141,375],
[87,223,375],
[5,386,323],
[79,333,3],
[36,5,4],
[310,354,50],
[395,388,351],
[184,128,194],
[195,6,196],
[240,270,253],
[76,7,224],
[216,8,200],
[174,279,123],
[9,6,195],
[201,275,10],
[91,291,11],
[330,110,285],
[12,202,116],
[202,12,363],
[317,13,244],
[203,113,150],
[206,14,157],
[15,130,403],
[204,14,231],
[362,135,111],
[162,106,16],
[205,283,7],
[402,326,175],
[297,17,372],
[65,219,18],
[113,124,236],
[29,19,33],
[206,103,308],
[20,134,21],
[208,331,277],
[136,133,339],
[218,178,260],
[22,24,23],
[360,1,308],
[401,56,219],
[404,70,71],
[208,209,25],
[211,243,210],
[300,22,102],
[408,26,194],
[211,263,216],
[213,209,277],
[27,134,380],
[363,364,10],
[28,29,48],
[214,138,349],
[369,274,30],
[29,28,215],
[119,352,148],
[266,295,296],
[75,212,216],
[217,31,146],
[218,225,71],
[3,88,246],
[219,32,349],
[394,125,248],
[220,359,5],
[33,34,221],
[128,340,222],
[105,238,170],
[19,56,34],
[243,35,223],
[258,36,192],
[7,77,2],
[225,218,304],
[226,277,331],
[37,394,318],
[67,261,41],
[290,17,297],
[38,39,228],
[336,93,40],
[22,300,301],
[41,42,230],
[14,206,43],
[44,290,227],
[60,179,393],
[106,64,258],
[232,58,229],
[203,205,76],
[69,355,233],
[139,391,179],
[234,97,235],
[45,294,236],
[237,46,238],
[391,286,239],
[32,190,122],
[47,289,270],
[241,345,85],
[73,48,144],
[81,86,49],
[145,193,50],
[212,35,243],
[355,107,315],
[364,121,325],
[39,360,51],
[52,117,278],
[101,53,376],
[16,258,54],
[13,0,245],
[156,319,110],
[246,9,380],
[215,316,247],
[106,162,181],
[125,140,385],
[249,192,4],
[362,255,55],
[132,126,251],
[252,59,253],
[56,19,32],
[342,343,347],
[244,245,311],
[255,234,262],
[185,393,62],
[78,318,57],
[205,203,58],
[144,96,297],
[166,373,352],
[80,49,256],
[55,262,257],
[197,253,59],
[399,60,185],
[61,62,53],
[10,364,63],
[263,353,8],
[82,340,128],
[64,220,36],
[332,68,324],
[260,67,382],
[188,401,65],
[82,46,261],
[262,235,378],
[66,239,306],
[178,153,67],
[294,280,233],
[75,289,68],
[276,169,353],
[13,317,72],
[202,109,69],
[115,225,264],
[265,71,70],
[176,189,266],
[46,237,41],
[72,73,242],
[117,301,267],
[281,83,269],
[77,151,74],
[324,396,310],
[289,75,199],
[137,76,198],
[283,169,77],
[255,111,379],
[271,273,114],
[176,37,78],
[79,81,80],
[273,164,274],
[118,340,82],
[342,254,83],
[275,85,84],
[23,287,302],
[276,173,186],
[277,226,278],
[279,174,281],
[86,81,3],
[361,87,191],
[88,3,333],
[283,205,232],
[110,89,377],
[286,47,240],
[24,345,287],
[143,102,306],
[288,68,289],
[25,337,90],
[156,328,17],
[373,398,381],
[291,91,292],
[293,370,142],
[104,378,235],
[273,271,92],
[252,200,8],
[154,400,93],
[54,241,275],
[169,276,151],
[316,244,94],
[287,249,250],
[45,279,280],
[26,95,341],
[295,271,358],
[96,38,227],
[357,265,299],
[15,115,135],
[171,246,257],
[147,350,97],
[366,367,224],
[300,400,154],
[182,98,302],
[58,150,90],
[147,100,99],
[56,401,339],
[197,306,239],
[303,357,298],
[337,336,229],
[304,260,383],
[73,72,317],
[101,346,397],
[102,23,307],
[103,99,51],
[173,276,263],
[0,237,105],
[48,33,30],
[236,294,315],
[396,112,354],
[104,157,14],
[93,252,384],
[274,164,38],
[245,105,312],
[282,191,313],
[248,385,314],
[64,106,335],
[92,356,360],
[107,25,309],
[322,334,141],
[316,215,28],
[42,108,163],
[88,6,9],
[318,248,256],
[109,202,160],
[89,110,319],
[377,379,111],
[140,125,322],
[182,250,4],
[68,288,396],
[83,254,325],
[217,80,314],
[161,310,193],
[35,332,259],
[371,161,389],
[112,183,139],
[124,113,251],
[91,114,368],
[71,225,115],
[116,69,268],
[27,195,175],
[24,22,117],
[280,281,268],
[160,363,84],
[305,285,264],
[118,303,327],
[167,119,296],
[329,330,305],
[402,120,21],
[200,253,270],
[328,156,330],
[121,116,269],
[355,69,109],
[212,75,332],
[31,214,122],
[45,124,123],
[333,79,94],
[125,394,334],
[335,181,126],
[213,154,336],
[347,348,127],
[194,128,406],
[44,99,100],
[209,213,337],
[129,207,21],
[130,390,131],
[159,153,303],
[338,335,132],
[133,221,34],
[0,13,108],
[340,118,407],
[238,184,341],
[342,180,344],
[359,220,367],
[155,333,311],
[134,27,326],
[135,115,320],
[345,241,249],
[163,328,329],
[397,346,292],
[49,204,57],
[113,203,137],
[140,138,214],
[11,370,398],
[391,139,183],
[138,140,321],
[191,375,141],
[272,78,231],
[346,101,142],
[343,162,348],
[400,300,143],
[274,96,144],
[138,145,18],
[123,251,126],
[393,182,323],
[190,215,146],
[241,54,192],
[386,53,62],
[350,147,103],
[351,148,352],
[353,284,384],
[85,52,149],
[150,236,309],
[187,65,50],
[151,186,152],
[158,187,354],
[208,107,355],
[356,92,271],
[153,178,357],
[154,213,267],
[196,155,312],
[91,167,358],
[374,165,188],
[388,266,148],
[291,142,370],
[359,365,386],
[356,189,1],
[319,156,290],
[86,104,204],
[97,350,157],
[254,347,63],
[158,139,60],
[345,24,52],
[210,243,87],
[130,135,362],
[12,121,364],
[367,338,198],
[334,395,313],
[153,159,261],
[98,66,307],
[226,160,149],
[365,359,366],
[108,72,372],
[368,369,221],
[220,64,338],
[114,273,369],
[152,398,370],
[131,390,207],
[259,324,161],
[162,343,344],
[74,152,293],
[17,328,163],
[164,92,39],
[373,361,282],
[397,136,165],
[166,119,167],
[100,147,172],
[223,259,371],
[376,365,168],
[169,283,284],
[95,196,170],
[89,172,379],
[104,86,171],
[172,97,234],
[20,55,380],
[145,321,389],
[186,173,210],
[230,329,383],
[284,232,40],
[174,180,83],
[385,214,31],
[365,376,53],
[99,44,228],
[387,175,26],
[37,176,388],
[321,322,177],
[362,20,207],
[292,368,133],
[178,218,265],
[66,98,179],
[180,174,392],
[47,286,183],
[348,16,201],
[181,344,392],
[179,98,182],
[394,37,395],
[183,112,396],
[46,82,184],
[320,264,285],
[374,185,61],
[189,176,272],
[152,186,381],
[399,188,187],
[400,59,252],
[401,188,165],
[381,361,373],
[79,247,94],
[189,295,266],
[237,42,41],
[19,190,32],
[6,155,196],
[1,43,308],
[175,95,26],
[168,2,74],
[177,375,371],
[87,375,191],
[5,323,4],
[79,3,81],
[36,4,192],
[310,50,193],
[395,351,313],
[184,194,341],
[195,196,95],
[240,253,197],
[76,224,198],
[216,200,199],
[174,123,392],
[9,195,27],
[201,10,127],
[91,11,167],
[330,285,305],
[12,116,121],
[202,363,160],
[317,244,316],
[203,150,58],
[206,157,350],
[15,403,404],
[204,231,57],
[362,111,255],
[162,16,348],
[205,7,76],
[402,175,387],
[297,372,242],
[65,18,50],
[113,236,150],
[29,33,48],
[206,308,43],
[20,21,207],
[208,277,209],
[136,339,165],
[218,260,304],
[22,23,102],
[360,308,51],
[401,219,65],
[404,71,15],
[208,25,107],
[211,210,173],
[300,102,143],
[408,194,405],
[211,216,212],
[213,277,267],
[27,380,9],
[363,10,84],
[28,48,73],
[214,349,122],
[369,30,221],
[29,215,190],
[119,148,296],
[266,296,148],
[75,216,199],
[217,146,247],
[218,71,265],
[3,246,171],
[219,349,18],
[394,248,318],
[220,5,36],
[33,221,30],
[128,222,406],
[105,170,312],
[19,34,33],
[243,223,87],
[258,192,54],
[7,2,224],
[225,304,264],
[226,331,109],
[37,318,78],
[67,41,382],
[290,297,227],
[38,228,227],
[336,40,229],
[22,301,117],
[41,230,382],
[14,43,231],
[44,227,228],
[60,393,185],
[106,258,16],
[232,229,40],
[203,76,137],
[69,233,268],
[139,179,60],
[234,235,262],
[45,236,124],
[237,238,105],
[391,239,66],
[32,122,349],
[47,270,240],
[241,85,275],
[73,144,242],
[81,49,80],
[145,50,18],
[212,243,211],
[355,315,233],
[364,325,63],
[39,51,228],
[52,278,149],
[101,376,142],
[16,54,201],
[13,245,244],
[156,110,330],
[246,380,257],
[215,247,146],
[106,181,335],
[125,385,248],
[249,4,250],
[362,55,20],
[132,251,137],
[252,253,200],
[56,32,219],
[342,347,254],
[244,311,94],
[255,262,55],
[185,62,61],
[78,57,231],
[205,58,232],
[144,297,242],
[166,352,119],
[80,256,314],
[55,257,380],
[197,59,143],
[399,185,374],
[61,53,101],
[10,63,127],
[263,8,216],
[82,128,184],
[64,36,258],
[332,324,259],
[260,382,383],
[188,65,187],
[82,261,159],
[262,378,257],
[66,306,307],
[178,67,260],
[294,233,315],
[75,68,332],
[276,353,263],
[13,72,108],
[202,69,116],
[115,264,320],
[265,70,299],
[176,266,388],
[46,41,261],
[72,242,372],
[117,267,278],
[281,269,268],
[77,74,2],
[324,310,161],
[289,199,270],
[137,198,132],
[283,77,7],
[255,379,234],
[271,114,358],
[176,78,272],
[79,80,217],
[273,274,369],
[118,82,159],
[342,83,180],
[275,84,10],
[23,302,307],
[276,186,151],
[277,278,267],
[279,281,280],
[86,3,171],
[361,191,282],
[88,333,155],
[283,232,284],
[110,377,285],
[286,240,239],
[24,287,23],
[143,306,197],
[288,289,47],
[25,90,309],
[156,17,290],
[398,373,166],
[291,292,346],
[293,142,376],
[104,235,157],
[273,92,164],
[252,8,384],
[154,93,336],
[54,275,201],
[169,151,77],
[316,94,247],
[287,250,302],
[45,280,294],
[26,341,194],
[295,358,296],
[96,227,297],
[357,299,298],
[15,135,130],
[171,257,378],
[147,97,172],
[366,224,2],
[300,154,301],
[182,302,250],
[58,90,229],
[147,99,103],
[56,339,34],
[197,239,240],
[303,298,327],
[337,229,90],
[304,383,305],
[73,317,28],
[101,397,61],
[102,307,306],
[103,51,308],
[173,263,211],
[0,105,245],
[48,30,144],
[236,315,309],
[396,354,310],
[104,14,204],
[93,384,40],
[274,38,96],
[245,312,311],
[282,313,351],
[248,314,256],
[64,335,338],
[92,360,39],
[107,309,315],
[322,141,177],
[316,28,317],
[42,163,230],
[88,9,246],
[318,256,57],
[109,160,226],
[89,319,100],
[377,111,320],
[140,322,321],
[182,4,323],
[68,396,324],
[83,325,269],
[217,314,31],
[161,193,389],
[35,259,223],
[371,389,177],
[112,139,158],
[124,251,123],
[91,368,292],
[71,115,15],
[116,268,269],
[27,175,326],
[24,117,52],
[280,268,233],
[160,84,149],
[305,264,304],
[118,327,407],
[167,296,358],
[329,305,383],
[402,21,326],
[200,270,199],
[328,330,329],
[121,269,325],
[355,109,331],
[212,332,35],
[31,122,146],
[45,123,279],
[333,94,311],
[125,334,322],
[335,126,132],
[213,336,337],
[347,127,63],
[194,406,405],
[44,100,319],
[209,337,25],
[129,21,120],
[130,131,403],
[159,303,118],
[338,132,198],
[133,34,339],
[0,108,42],
[340,407,222],
[238,341,170],
[342,344,343],
[359,367,366],
[155,311,312],
[134,326,21],
[135,320,111],
[345,249,287],
[163,329,230],
[397,292,136],
[49,57,256],
[113,137,251],
[140,214,385],
[11,398,166],
[391,183,286],
[138,321,145],
[191,141,313],
[272,231,43],
[346,142,291],
[343,348,347],
[400,143,59],
[274,144,30],
[138,18,349],
[123,126,392],
[393,323,62],
[190,146,122],
[241,192,249],
[386,62,323],
[350,103,206],
[351,352,282],
[353,384,8],
[85,149,84],
[150,309,90],
[187,50,354],
[151,152,74],
[158,354,112],
[208,355,331],
[356,271,295],
[153,357,303],
[154,267,301],
[196,312,170],
[91,358,114],
[374,188,399],
[388,148,351],
[291,370,11],
[359,386,5],
[356,1,360],
[319,290,44],
[86,204,49],
[97,157,235],
[254,63,325],
[158,60,399],
[345,52,85],
[210,87,361],
[130,362,390],
[12,364,363],
[367,198,224],
[334,313,141],
[153,261,67],
[98,307,302],
[226,149,278],
[365,366,168],
[108,372,163],
[368,221,133],
[220,338,367],
[114,369,368],
[152,370,293],
[131,207,129],
[259,161,371],
[162,344,181],
[74,293,168],
[17,163,372],
[164,39,38],
[373,282,352],
[397,165,374],
[166,167,11],
[100,172,89],
[223,371,375],
[376,168,293],
[169,284,353],
[95,170,341],
[89,379,377],
[104,171,378],
[172,234,379],
[20,380,134],
[145,389,193],
[186,210,381],
[230,383,382],
[284,40,384],
[174,83,281],
[385,31,314],
[365,53,386],
[99,228,51],
[387,26,408],
[37,388,395],
[321,177,389],
[362,207,390],
[292,133,136],
[178,265,357],
[66,179,391],
[180,392,344],
[47,183,288],
[348,201,127],
[181,392,126],
[179,182,393],
[394,395,334],
[183,396,288],
[46,184,238],
[320,285,377],
[374,61,397],
[189,272,1],
[398,152,381],
[399,187,158],
[400,252,93],
[401,165,339],
[402,408,70],
[387,408,402],
[402,70,120],
[120,404,129],
[129,403,131],
[404,403,129],
[404,120,70],
[70,408,299],
[299,405,298],
[298,405,327],
[327,406,407],
[407,406,222],
[406,327,405],
[405,299,408]
]
    volume = 0.0

    for face in faces:
        v1 = vertices[face[0]]
        v2 = vertices[face[1]]
        v3 = vertices[face[2]]

        # 计算三角形面片与原点形成的四面体体积
        cross_product = tf.cross(v2, v3)
        dot_product = tf.tensordot(v1, cross_product, axes=1)  # 点积
        tetra_volume = dot_product / 6.0
        volume += tf.abs(tetra_volume)  # 取绝对值

    return volume

def main(_):
  """Train or evaluates the model."""

  if FLAGS.mode in ['train', 'eval']:
    estimator = tf_estimator.Estimator(
        get_one_step_estimator_fn(FLAGS.data_path, FLAGS.noise_std),
        model_dir=FLAGS.model_path)
    if FLAGS.mode == 'train':
      # Train all the way through.
      estimator.train(
          input_fn=get_input_fn(FLAGS.data_path, FLAGS.batch_size,
                                mode='one_step_train', split='train'),
          max_steps=FLAGS.num_steps)
    else:
      logging.info("Starting evaluation...")
      # One-step evaluation from checkpoint.
      eval_metrics = estimator.evaluate(input_fn=get_input_fn(
          FLAGS.data_path, FLAGS.batch_size,
          mode='one_step', split=FLAGS.eval_split))
      logging.info('Evaluation metrics:')
      logging.info(eval_metrics)
  elif FLAGS.mode == 'eval_rollout':
    if not FLAGS.output_path:
      raise ValueError('A rollout path must be provided.')
    rollout_estimator = tf_estimator.Estimator(
        get_rollout_estimator_fn(FLAGS.data_path, FLAGS.noise_std),
        model_dir=FLAGS.model_path)

    # Iterate through rollouts saving them one by one.
    metadata = _read_metadata(FLAGS.data_path)

    rollout_iterator = rollout_estimator.predict(
        input_fn=get_input_fn(FLAGS.data_path, batch_size=1,
                              mode='rollout', split=FLAGS.eval_split))

    # 记录开始时间
    start_time = time.time()

    for example_index, example_rollout in enumerate(rollout_iterator):
      example_rollout['metadata'] = metadata
      filename = f'rollout_{FLAGS.eval_split}_{example_index}.pkl'
      filename = os.path.join(FLAGS.output_path, filename)
      logging.info('Saving: %s.', filename)
      if not os.path.exists(FLAGS.output_path):
        os.mkdir(FLAGS.output_path)
      with open(filename, 'wb') as file:
        pickle.dump(example_rollout, file)

    # 记录结束时间
    end_time = time.time()

    # 计算总耗时
    total_time = end_time - start_time
    logging.info('Total prediction time: %.2f seconds.', total_time)



if __name__ == '__main__':
  tf.disable_v2_behavior()

  # 列出所有可用的 GPU 设备
  physical_devices = tf.config.experimental.list_physical_devices('GPU')
  # 如果没有找到 GPU 设备，抛出一个错误
  assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
  # 为每个检测到的 GPU 设备设置内存增长
  for gpu in physical_devices:
      tf.config.experimental.set_memory_growth(gpu, True)

  app.run(main)
