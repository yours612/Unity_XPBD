# pylint: disable=g-bad-file-header
# Copyright 2020 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or  implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Full model implementation accompanying ICML 2020 submission.

   "Learning to Simulate Complex Physics with Graph Networks"

   Alvaro Sanchez-Gonzalez*, Jonathan Godwin*, Tobias Pfaff*, Rex Ying,
   Jure Leskovec, Peter W. Battaglia

   https://arxiv.org/abs/2002.09405

"""

import graph_nets as gn
import sonnet as snt
#import tensorflow.compat.v1 as tf
import tensorflow as tf
import numpy as np


from learning_to_simulate import connectivity_utils
from learning_to_simulate import graph_network
from learning_to_simulate import normalization

STD_EPSILON = 1e-8


class LearnedSimulator(snt.AbstractModule):
  """Learned simulator from https://arxiv.org/pdf/2002.09405.pdf."""

  def __init__(
      self,
      num_dimensions,
      connectivity_radius,
      graph_network_kwargs,
      boundaries,
      normalization_stats,
      num_particle_types,
      particle_type_embedding_size,
      name="LearnedSimulator"):
    """Inits the model.

    Args:
      num_dimensions: Dimensionality of the problem.
      connectivity_radius: Scalar with the radius of connectivity.
      graph_network_kwargs: Keyword arguments to pass to the learned part
        of the graph network `model.EncodeProcessDecode`.
      boundaries: List of 2-tuples, containing the lower and upper boundaries of
        the cuboid containing the particles along each dimensions, matching
        the dimensionality of the problem.
      normalization_stats: Dictionary with statistics with keys "acceleration"
        and "velocity", containing a named tuple for each with mean and std
        fields, matching the dimensionality of the problem.
      num_particle_types: Number of different particle types.
      particle_type_embedding_size: Embedding size for the particle type.
      name: Name of the Sonnet module.

    """
    super().__init__(name=name)


    self._connectivity_radius = connectivity_radius
    self._num_particle_types = num_particle_types
    self._boundaries = boundaries
    self._normalization_stats = normalization_stats
    with self._enter_variable_scope():
      self._graph_network = graph_network.EncodeProcessDecode(
          output_size=num_dimensions, **graph_network_kwargs)


      if self._num_particle_types > 1:
        self._particle_type_embedding = tf.get_variable(
            "particle_embedding",
            [self._num_particle_types, particle_type_embedding_size],
            trainable=True, use_resource=True)

    self._node_normalizer = normalization.Normalizer(size=9)  # 15+18  3+3
    self._edge_normalizer = normalization.Normalizer(size=4)  # Adjust size as needed
    self._output_normalizer = normalization.Normalizer(size=3)

  def _build(self, force_sequence, f_points, position_sequence, n_particles_per_example,
             global_context=None, particle_types=None):
    """Produces a model step, outputting the next position for each particle.

    Args:
      position_sequence: Sequence of positions for each node in the batch,
        with shape [num_particles_in_batch, sequence_length, num_dimensions]
      n_particles_per_example: Number of particles for each graph in the batch
        with shape [batch_size]
      global_context: Tensor of shape [batch_size, context_size], with global
        context.
      particle_types: Integer tensor of shape [num_particles_in_batch] with
        the integer types of the particles, from 0 to `num_particle_types - 1`.
        If None, we assume all particles are the same type.

    Returns:
      Next position with shape [num_particles_in_batch, num_dimensions] for one
      step into the future from the input sequence.
    """
    input_graphs_tuple = self._encoder_preprocessor(force_sequence, f_points,
        position_sequence, n_particles_per_example, global_context,
        particle_types, is_training=False)

    normalized_acceleration = self._graph_network(input_graphs_tuple)

    next_position = self._decoder_postprocessor(
        normalized_acceleration, position_sequence)

    return next_position

  def _encoder_preprocessor(
      self, force_sequence, f_points,
          position_sequence, n_node, global_context, particle_types, is_training):
    # Extract important features from the position_sequence.
    most_recent_position = position_sequence[:, -1] # position_sequence 的所有粒子的最后一个时间步的位置信息
    velocity_sequence = time_diff(position_sequence)  # Finite-difference.

    # Get connectivity of the graph.
    (senders, receivers, n_edge, edge_lens
     ) = connectivity_utils.compute_connectivity_for_batch_pyfunc(
         most_recent_position, n_node, self._connectivity_radius)

    # Normalized velocity sequence, merging spatial an time axis.
    velocity_stats = self._normalization_stats["velocity"]
    normalized_velocity_sequence = (
        velocity_sequence - velocity_stats.mean) / velocity_stats.std

    flat_velocity_sequence = snt.MergeDims(start=1, size=2)(
        velocity_sequence)
    flat_pos_sequence = snt.MergeDims(start=1, size=2)(
        position_sequence)
    #node_features.append(normalized_velocity_sequence)

    # f_mean = np.array([-9.695319555555557e-05, -9.786906888888885e-05, -0.0002042628544444445])
    # f_std = np.array([0.0007050703866666665, 0.0007238411611111111, 0.0008037967466666665])

    manual_force_indices = f_points
    # 创建标记向量，形状为 [num_nodes, 1]
    manually_forced_node_mask = tf.zeros([409, 1], dtype=tf.float32)
    manually_forced_node_mask = tf.tensor_scatter_nd_update(
        manually_forced_node_mask,
        indices=tf.reshape(manual_force_indices, [-1, 1]),
        updates = tf.fill([tf.shape(manual_force_indices)[0], 1], tf.constant(1.0, dtype=tf.float32))
    )

    flat_force_sequence = snt.MergeDims(start=1, size=2)(force_sequence)
    cur_force = flat_force_sequence[:, -3:]
    #node_features.append(normalized_force_sequence)

    #node_features = tf.concat([flat_velocity_sequence, cur_force, manually_forced_node_mask], axis=-1)

    node_features = flat_velocity_sequence

    node_features = self._node_normalizer(node_features, is_training)

    # # 扩展维度，使 manually_forced_node_mask 变成 [409, 1, 1] 的形状
    # manually_forced_node_mask_expanded = tf.expand_dims(manually_forced_node_mask, axis=1)
    # # 使用 tf.tile 复制它，变成 [409, sequence_length, 1] 的形状
    # manually_forced_node_mask_rnn = tf.tile(manually_forced_node_mask_expanded, [1, tf.shape(velocity_sequence)[1], 1])
    # node_features_rnn = tf.concat([velocity_sequence, force_sequence[:, 1:, :], manually_forced_node_mask_rnn], axis=-1)
    # batch_size, sequence_length, feature_dim = node_features_rnn.shape
    # node_features_rnn_flat = tf.reshape(node_features_rnn, [-1, feature_dim])
    # #node_features_rnn_normalized_flat = self._node_normalizer(node_features_rnn_flat, is_training)
    # node_features_rnn_normalized = tf.reshape(node_features_rnn_normalized_flat,
    #                                           [batch_size, sequence_length, feature_dim])

    # Particle type.
    if self._num_particle_types > 1:
      particle_type_embeddings = tf.nn.embedding_lookup(
          self._particle_type_embedding, particle_types)
      #node_features.append(particle_type_embeddings)

    #edge_features = []

    edge_lens = tf.expand_dims(edge_lens, axis=-1)
    relative_displacements = (
        tf.gather(most_recent_position, senders) -
        tf.gather(most_recent_position, receivers)) #/ self._connectivity_radius

    # 计算方向向量（单位化）
    #normalized_relative_displacements = tf.linalg.l2_normalize(relative_displacements, axis=-1)
    # 计算当前边长度的模长
    current_edge_lengths = tf.norm(relative_displacements, axis=-1, keepdims=True) #/ edge_lens

    # edge_length_ratio = current_edge_lengths / edge_lens

    # |||||||||||| [num_particles_in_batch, num_dimensions + 1]
    edge_features = tf.concat([relative_displacements, current_edge_lengths], axis=-1)
    edge_features = self._edge_normalizer(edge_features, is_training)

    # #----------------------------------------------------------------rnn
    # multi_time_positions = position_sequence[:, 1:]
    # sender_positions = tf.gather(multi_time_positions, senders,
    #                              axis=0)  # 选择粒子位置，维度: (num_pairs, sequence_length - 1, num_dimensions)
    # receiver_positions = tf.gather(multi_time_positions, receivers,
    #                                axis=0)  # 维度: (num_pairs, sequence_length - 1, num_dimensions)
    # # 计算相对位移
    # relative_displacements_rnn = sender_positions - receiver_positions  # 维度: (num_pairs, sequence_length - 1, num_dimensions)
    # relative_displacement_magnitude_rnn = tf.norm(relative_displacements_rnn, axis=-1, keepdims=True)
    #
    # relative_displacement_magnitude_rnn_expanded = tf.expand_dims(relative_displacement_magnitude_rnn,
    #                                                              axis=-1)  # 维度: (num_pairs, sequence_length - 1, 1)
    #
    # # 使用 tf.tile 扩展到 (num_pairs, sequence_length - 1, num_dimensions)
    # relative_displacement_magnitude_rnn_expanded = tf.tile(relative_displacement_magnitude_rnn_expanded,
    #                                                        [1, 1, 3])
    # # 拼接相对位移和幅度
    # edge_features_rnn = tf.concat([relative_displacements_rnn, relative_displacement_magnitude_rnn_expanded], axis=-1)
    # # 归一化边特征
    # #edge_features_rnn = self._edge_normalizer(edge_features_rnn, is_training)
    # # ------------------------------------rnn


    # Normalize the global context.
    if global_context is not None:
      context_stats = self._normalization_stats["context"]
      # Context in some datasets are all zero, so add an epsilon for numerical
      # stability.
      global_context = (global_context - context_stats.mean) / tf.math.maximum(
          context_stats.std, STD_EPSILON)

    graph = gn.graphs.GraphsTuple(
        nodes=node_features,
        edges=edge_features,
        globals=global_context,  # self._graph_net will appending this to nodes.
        n_node=n_node,
        n_edge=n_edge,
        senders=senders,
        receivers=receivers,
        )
    return graph

  def _decoder_postprocessor(self, normalized_acceleration, position_sequence):

    # The model produces the output in normalized space so we apply inverse
    # normalization.
    acceleration_stats = self._normalization_stats["acceleration"]
    acceleration = (
        normalized_acceleration * acceleration_stats.std
        ) + acceleration_stats.mean

    acceleration_normalized = self._output_normalizer.inverse(normalized_acceleration)

    # Use an Euler integrator to go from acceleration to position, assuming
    # a dt=1 corresponding to the size of the finite difference.
    most_recent_position = position_sequence[:, -1]
    most_recent_velocity = most_recent_position - position_sequence[:, -2]

    new_velocity = most_recent_velocity + acceleration_normalized  # * dt = 1
    new_position = most_recent_position + new_velocity  # * dt = 1
    return new_position

  def get_predicted_and_target_normalized_accelerations(
      self, next_position, force_sequence, f_points,
          position_sequence_noise, position_sequence,
      n_particles_per_example, global_context=None, particle_types=None):  # pylint: disable=g-doc-args
    """Produces normalized and predicted acceleration targets.

    Args:
      next_position: Tensor of shape [num_particles_in_batch, num_dimensions]
        with the positions the model should output given the inputs.
      position_sequence_noise: Tensor of the same shape as `position_sequence`
        with the noise to apply to each particle.
      position_sequence, n_node, global_context, particle_types: Inputs to the
        model as defined by `_build`.

    Returns:
      Tensors of shape [num_particles_in_batch, num_dimensions] with the
        predicted and target normalized accelerations.
    """

    # Add noise to the input position sequence.
    noisy_position_sequence = position_sequence + position_sequence_noise

    # Perform the forward pass with the noisy position sequence.
    input_graphs_tuple = self._encoder_preprocessor(force_sequence, f_points,
        noisy_position_sequence, n_particles_per_example, global_context,
        particle_types, is_training=True)
    predicted_normalized_acceleration = self._graph_network(input_graphs_tuple)

    # Calculate the target acceleration, using an `adjusted_next_position `that
    #     # is shifted by the noise in the last input position.
    next_position_adjusted = next_position + position_sequence_noise[:, -1]
    target_normalized_acceleration = self._inverse_decoder_postprocessor(
        next_position_adjusted, noisy_position_sequence)
    # As a result the inverted Euler update in the `_inverse_decoder` produces:
    # * A target acceleration that does not explicitly correct for the noise in
    #   the input positions, as the `next_position_adjusted` is different
    #   from the true `next_position`.
    # * A target acceleration that exactly corrects noise in the input velocity
    #   since the target next velocity calculated by the inverse Euler update
    #   as `next_position_adjusted - noisy_position_sequence[:,-1]`
    #   matches the ground truth next velocity (noise cancels out).

    return predicted_normalized_acceleration, target_normalized_acceleration

  def _inverse_decoder_postprocessor(self, next_position, position_sequence):
    """Inverse of `_decoder_postprocessor`."""

    previous_position = position_sequence[:, -1]
    previous_velocity = previous_position - position_sequence[:, -2]
    next_velocity = next_position - previous_position
    acceleration = next_velocity - previous_velocity

    target_normalized = self._output_normalizer(acceleration)

    acceleration_stats = self._normalization_stats["acceleration"]
    normalized_acceleration = (
        acceleration - acceleration_stats.mean) / acceleration_stats.std
    return target_normalized


def time_diff(input_sequence):
  return input_sequence[:, 1:] - input_sequence[:, :-1]


