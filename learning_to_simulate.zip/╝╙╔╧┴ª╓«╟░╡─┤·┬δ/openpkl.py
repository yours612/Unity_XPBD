import pickle
import numpy as np

f = open('output\\myTest_PBD\\dannang\\all\\1message\\rollout_test_9.pkl','rb')   #pickle_data_path为.pickle文件的路径；
info = pickle.load(f)


#print(info.keys())  # 查看所有顶级键
#print(info['metadata'])  # 检查元数据
#print(info['initial_positions'])  # 检查初始位置数组的形状
#print(info['ground_truth_rollout'])  # 检查真实轨迹的形状
print(info['predicted_rollout'])  # 检查预测轨迹的形状

initial_positions = info['initial_positions']
predicted_rollout = info['predicted_rollout']
ground_truth_rollout = info['ground_truth_rollout']
# 将两个数组沿着时间轴合并，假设它们在时间步的维度上是匹配的
combined_data = np.concatenate((initial_positions, ground_truth_rollout), axis=0)
# 保存合并后的数组到文本文件
np.savetxt('output\\myTest_PBD\\sphere\\for_unity\\ground_truth_rollout.txt', combined_data.reshape(-1, combined_data.shape[-1]), fmt='%.6f')


# print(info)
f.close()  #别忘记close pickle文件