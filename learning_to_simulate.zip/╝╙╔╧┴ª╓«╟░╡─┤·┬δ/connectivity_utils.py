# pylint: disable=g-bad-file-header
# Copyright 2020 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or  implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Tools to compute the connectivity of the graph."""

import functools

import numpy as np
from sklearn import neighbors
#import tensorflow.compat.v1 as tf
import tensorflow as tf

no_R = False

def _compute_connectivity(positions, radius, add_self_edges):
  """Get the indices of connected edges with radius connectivity.

  Args:
    positions: Positions of nodes in the graph. Shape:
      [num_nodes_in_graph, num_dims].
    radius: Radius of connectivity.
    add_self_edges: Whether to include self edges or not.

  Returns:
    senders indices [num_edges_in_graph]
    receiver indices [num_edges_in_graph]

  """

  tree = neighbors.KDTree(positions)
  receivers_list = tree.query_radius(positions, r=radius)
  num_nodes = len(positions)
  senders = np.repeat(range(num_nodes), [len(a) for a in receivers_list])
  receivers = np.concatenate(receivers_list, axis=0)

  if not add_self_edges:
    # Remove self edges.
    mask = senders != receivers
    senders = senders[mask]
    receivers = receivers[mask]

  return senders, receivers

def _compute_connectivity_for_batch(
    positions, n_node, radius, add_self_edges):
  """`compute_connectivity` for a batch of graphs.

  Args:
    positions: Positions of nodes in the batch of graphs. Shape:
      [num_nodes_in_batch, num_dims].
    n_node: Number of nodes for each graph in the batch. Shape:
      [num_graphs in batch].
    radius: Radius of connectivity.
    add_self_edges: Whether to include self edges or not.

  Returns:
    senders indices [num_edges_in_batch]
    receiver indices [num_edges_in_batch]
    number of edges per graph [num_graphs_in_batch]

  """

  # TODO(alvarosg): Consider if we want to support batches here or not.
  # Separate the positions corresponding to particles in different graphs.
  positions_per_graph_list = np.split(positions, np.cumsum(n_node[:-1]), axis=0)
  receivers_list = []
  senders_list = []
  n_edge_list = []
  num_nodes_in_previous_graphs = 0

  # Compute connectivity for each graph in the batch.
  # 由于batch_size = 2，所以positions是两个轨迹的数据，n_node = [n1,n2]（表示两个轨迹中的顶点数）
  # 所以positions_per_graph_list表示两个图，也就是两个轨迹的位置
  for positions_graph_i in positions_per_graph_list:
    if no_R:
        senders_graph_i, receivers_graph_i = _compute_connectivity_from_edges()
    else:
        senders_graph_i, receivers_graph_i = _compute_connectivity(
            positions_graph_i, radius, add_self_edges)

    num_edges_graph_i = len(senders_graph_i)
    n_edge_list.append(num_edges_graph_i)

    # Because the inputs will be concatenated, we need to add offsets to the
    # sender and receiver indices according to the number of nodes in previous
    # graphs in the same batch.
    receivers_list.append(receivers_graph_i + num_nodes_in_previous_graphs)
    senders_list.append(senders_graph_i + num_nodes_in_previous_graphs)

    num_nodes_graph_i = len(positions_graph_i)
    num_nodes_in_previous_graphs += num_nodes_graph_i

  # Concatenate all of the results.
  senders = np.concatenate(senders_list, axis=0).astype(np.int32)
  receivers = np.concatenate(receivers_list, axis=0).astype(np.int32)
  n_edge = np.stack(n_edge_list).astype(np.int32)

  return senders, receivers, n_edge


def compute_connectivity_for_batch_pyfunc(
    positions, n_node, radius, add_self_edges=True):
  """`_compute_connectivity_for_batch` wrapped in a pyfunc."""
  partial_fn = functools.partial(
      _compute_connectivity_for_batch, add_self_edges=add_self_edges)
  senders, receivers, n_edge = tf.py_function(
      partial_fn,
      [positions, n_node, radius],
      [tf.int32, tf.int32, tf.int32])
  senders.set_shape([None])
  receivers.set_shape([None])
  n_edge.set_shape(n_node.get_shape())
  return senders, receivers, n_edge


def _compute_connectivity_from_edges():
    # 测试球体图结构用边来表示——————————————————————————————————————
    edges = [
        [89, 9], [9, 90], [90, 89], [81, 49], [49, 75], [75, 81], [31, 67], [67, 0], [0, 31], [63, 2],
        [2, 45], [45, 63], [16, 1], [1, 17], [17, 16], [47, 2], [2, 69], [69, 47], [4, 67], [67, 79],
        [79, 4], [8, 3], [3, 4], [4, 8], [8, 69], [69, 48], [48, 8], [49, 5], [5, 77], [77, 49],
        [77, 6], [6, 78], [78, 77], [6, 79], [79, 78], [39, 51], [51, 5], [5, 39], [5, 7], [7, 6],
        [6, 5], [7, 4], [4, 6], [87, 51], [51, 88], [88, 87], [50, 7], [7, 51], [51, 50], [7, 47],
        [47, 8], [8, 7], [9, 50], [50, 87], [87, 9], [10, 52], [52, 50], [50, 10], [52, 53], [53, 47],
        [47, 52], [59, 41], [41, 11], [11, 59], [12, 18], [18, 59], [59, 12], [12, 17], [17, 13], [13, 12],
        [54, 57], [57, 55], [55, 54], [55, 56], [56, 42], [42, 55], [56, 11], [11, 42], [14, 15], [15, 57],
        [57, 14], [57, 58], [58, 56], [56, 57], [58, 59], [59, 56], [83, 15], [15, 33], [33, 83], [60, 58],
        [58, 15], [15, 60], [58, 16], [16, 12], [12, 58], [62, 60], [60, 83], [83, 62], [27, 61], [61, 60],
        [60, 27], [61, 25], [25, 16], [16, 61], [21, 41], [41, 18], [18, 21], [23, 91], [91, 21], [21, 23],
        [23, 45], [45, 93], [93, 23], [1, 19], [19, 17], [17, 20], [20, 13], [20, 18], [18, 13], [64, 65],
        [65, 19], [19, 64], [19, 66], [66, 20], [20, 19], [66, 21], [21, 20], [0, 65], [65, 22], [22, 0],
        [24, 66], [66, 65], [65, 24], [66, 63], [63, 23], [23, 66], [67, 24], [24, 0], [3, 68], [68, 24],
        [24, 3], [68, 69], [69, 63], [63, 68], [26, 1], [1, 25], [25, 26], [74, 64], [64, 26], [26, 74],
        [74, 0], [22, 74], [62, 70], [70, 27], [27, 62], [27, 71], [71, 28], [28, 27], [71, 25], [25, 28],
        [80, 73], [73, 70], [70, 80], [70, 76], [76, 71], [71, 70], [76, 26], [26, 71], [75, 73], [73, 72],
        [72, 75], [29, 76], [76, 73], [73, 29], [76, 31], [31, 74], [74, 76], [49, 29], [29, 75], [77, 30],
        [30, 29], [29, 77], [30, 79], [79, 31], [31, 30], [82, 62], [83, 82], [32, 80], [80, 82], [82, 32],
        [32, 75], [72, 32], [54, 84], [84, 14], [14, 54], [14, 35], [35, 33], [33, 14], [35, 83], [34, 85],
        [85, 84], [84, 34], [84, 86], [86, 35], [35, 84], [86, 82], [82, 35], [90, 85], [85, 36], [36, 90],
        [37, 86], [86, 85], [85, 37], [86, 81], [81, 32], [32, 86], [9, 37], [37, 90], [87, 38], [38, 37],
        [37, 87], [38, 39], [39, 81], [81, 38], [44, 54], [55, 44], [40, 34], [34, 44], [44, 40], [40, 90],
        [36, 40], [41, 92], [92, 11], [11, 43], [43, 42], [43, 55], [91, 94], [94, 92], [92, 91], [92, 95],
        [95, 43], [43, 92], [95, 44], [44, 43], [45, 94], [94, 93], [96, 95], [95, 94], [94, 96], [95, 89],
        [89, 40], [40, 95], [2, 96], [96, 45], [53, 46], [46, 96], [96, 53], [46, 10], [10, 89], [89, 46],
        [10, 9], [39, 49], [53, 2], [3, 67], [48, 3], [39, 88], [52, 7], [10, 97], [97, 52], [97, 53], [61, 58],
        [28, 61], [91, 41], [93, 91], [1, 64], [64, 22], [68, 66], [48, 68], [62, 80], [80, 72], [30, 76], [78, 30],
        [54, 34], [34, 36], [38, 86], [88, 38], [46, 95], [97, 46],
    ]

    edges_array = np.array(edges)
    new_edges = np.empty((len(edges_array) * 2, 2), dtype=np.int32)
    new_edges[::2] = edges_array
    new_edges[1::2] = edges_array[:, ::-1]  # Reverse edges
    senders, receivers = new_edges[:, 0], new_edges[:, 1]
    return senders, receivers


# 测试2DBox图结构用边来表示——————————————————————————————————————
# _edges = [[0, 5], [0, 1], [0, 6], [1, 6], [1, 7], [1, 2], [1, 5], [2, 7], [2, 3], [2, 6], [2, 8],
#           [3, 8], [3, 4], [3, 7], [3, 9], [4, 9], [4, 8], [5, 10], [5, 6], [5, 1],
#           [6, 11], [6, 7], [6, 10], [6, 12], [7, 12], [7, 8], [7, 11], [7, 13], [8, 13], [8, 9],
#           [8, 12], [8, 14], [9, 14], [9, 13], [10, 15], [10, 11], [10, 16], [11, 16], [11, 12],
#           [11, 15],[11,17],[12,17],[12,13],[12,16],[12,18],[13,18],[13,14],
#           [13,17],[13,19],[14,19],[14,18],[15,16],[16,17],[17,18],[18,19],
#           ]


