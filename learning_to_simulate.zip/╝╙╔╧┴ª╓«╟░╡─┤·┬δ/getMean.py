import numpy as np

import os

def read_and_average(folder_path, num_files):
    # 初始化用于存储累加值和计数的字典
    sum_lines = {}

    # 构建文件名列表并排序，确保顺序正确
    files = [f"mean{i}.txt" for i in range(num_files)]

    # 遍历所有文件
    for file_name in files:
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, 'r') as file:
            for i, line in enumerate(file):
                # 提取数字，移除括号和空格
                numbers = line.strip()[1:-1].split(',')
                numbers = [float(num) for num in numbers]

                if i not in sum_lines:
                    sum_lines[i] = [0.0, 0.0, 0.0]

                # 累加当前行的每个元素
                for j in range(len(numbers)):
                    sum_lines[i][j] += numbers[j]

    # 计算每一行的平均值
    averages = []
    for line_sum in sum_lines.values():
        averages.append(tuple([x / num_files for x in line_sum]))

    return averages


# 用例: 计算给定文件夹内所有文件的行平均值
folder_path = 'E:\\python\\learning_to_simulate\\learning_to_simulate\\data\\myTest_PBD\\dannang\\mean'
num_files = 8  # 如果文件数不是20，请根据实际情况修改
average_values = read_and_average(folder_path, num_files)
for avg in average_values:
    print(avg)
