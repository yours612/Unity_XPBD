import h5py

## 'data\\BoxBath\\valid\\0\\0.h5'
## 'data\\BoxBath\\stat.h5'
# 打开HDF5文件
with h5py.File('data\\BoxBath\\stat.h5', 'r') as file:
    # 定义一个函数，用于检查并打印数据集内容
    def print_dataset(name, obj):
        if isinstance(obj, h5py.Dataset):  # 检查对象是否是数据集
            print(f"数据集名称: {name}")
            print("数据集内容:")
            print(obj[()])  # 打印数据集内容
            print("数据形状:", obj.shape)  # 打印数据集的形状
            print("数据数量:", obj.shape[0])  # 打印第一个维度的大小，即数据点数量
            print()  # 打印空行以提高可读性

    # 使用 visititems 方法遍历文件中的所有项
    file.visititems(print_dataset)