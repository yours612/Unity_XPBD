# Import modules and this file should be outside learning_to_simulate code folder
import functools
import os
import json
import pickle
import random

import tensorflow as tf
import numpy as np

##读取点---------
def load_positions_from_file(filename):
    # 读取文件的第一行以确定顶点数和时间步数
    with open(filename, 'r') as file:
        first_line = file.readline().strip()
        num_vertices, num_steps = map(int, first_line.split(','))

    # 创建一个空的数组用于存储从文件中读取的数据
    positions = np.zeros((num_steps, num_vertices, 3), dtype=np.float32)

    # 读取剩余的行，这些行分别表示每个时间步的顶点坐标
    with open(filename, 'r') as file:
        # 跳过第一行
        next(file)
        # 按顶点读取每个时间步的坐标
        for i in range(num_steps):
            for j in range(num_vertices):
                line = file.readline().strip()
                positions[i, j] = np.array(list(map(float, line.split(','))))

    return positions

# 设置生成数据的参数
num_steps = 1001  # 时间步数量
num_vertices = 98  # 假设每个时间步包含10个顶点
# x_range = (-1, 1.5)
# y_range = (-1, 1.5)
# z_range = (-1, 1.5)


tf.compat.v1.enable_eager_execution()

num_elements = num_vertices
particle_types =[]
keys=[]
positions = []
for i in range(5):  # range(15) 产生从0到14的数字
    keys.append(i)
    particle_types.append([1] * num_elements)

    data = load_positions_from_file(f"data\\myTest_PBD\\sphere\\test\\train\\{i+75}.txt")
    # new_pos = [[[x[0], x[1]] for x in group] for group in data]
    positions.append(data)

particle_types = [np.array(pt, dtype=np.int64) for pt in particle_types]
positions = [np.array(pos, dtype=np.float32) for pos in positions]

print(particle_types)
print(keys)
print(positions)


def _bytes_feature(value):
    """Returns a bytes_list from a string / byte."""
    if isinstance(value, type(tf.constant(0))):
        value = value.numpy() # BytesList won't unpack a string from an EagerTensor.
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))
def _float_feature(value):
    """Returns a float_list from a float / double."""
    return tf.train.Feature(float_list=tf.train.FloatList(value=[value]))
def _int64_feature(value):
    """Returns an int64_list from a bool / enum / int / uint."""
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))

#Write TF Record
with tf.io.TFRecordWriter('data\\myTest_PBD\\sphere\\test\\test.tfrecord') as writer:

    for step, (particle_type, key, position) in enumerate(zip(particle_types, keys, positions)):
        seq = tf.train.SequenceExample(
                context=tf.train.Features(feature={
                    "particle_type": _bytes_feature(particle_type.tobytes()),
                    "key": _int64_feature(key)
                }),
                feature_lists=tf.train.FeatureLists(feature_list={
                    'position': tf.train.FeatureList(
                        feature=[_bytes_feature(position.flatten().tobytes())],
                    ),
                    'step_context': tf.train.FeatureList(
                        feature=[_bytes_feature(np.float32(step).tobytes())]
                    ),
                })
            )

        writer.write(seq.SerializeToString())