import numpy as np


def read_vertices(filename, nums, steps):
    """
    从文件中读取顶点数据。
    参数：
    - filename: 文件名
    - nums: 顶点的数量
    - steps: 时间步的数量
    返回：
    - positions: 形状为(nums, steps, 2)的numpy数组，包含每个顶点在每个时间步的(x, y)坐标
    """
    positions = np.zeros((nums, steps, 2))
    with open(filename, 'r') as file:
        for i in range(nums):
            for j in range(steps):
                line = file.readline()
                x, y = map(float, line.split())
                positions[i, j] = [x, y]
    return positions


def calculate_velocity(positions, dt):
    """
    计算每个时间步的速度。
    参数：
    - positions: 顶点坐标数组
    - dt: 时间间隔
    返回：
    - velocities: 速度数组
    """
    # 计算速度，速度定义为相邻时间步位置变化除以时间间隔
    velocities = np.diff(positions, axis=1) / dt
    return velocities

def calculate_acceleration(velocities, dt):
    """
    计算加速度。
    参数：
    - velocities: 速度数组
    - dt: 时间间隔
    返回：
    - accelerations: 加速度数组
    """
    # 计算加速度，加速度定义为速度的时间导数
    accelerations = np.diff(velocities, axis=1) / dt
    return accelerations

def compute_stats(data):
    """
    计算数据的平均值和标准差。
    参数：
    - data: 要计算的数据数组
    返回：
    - mean: 平均值
    - std_dev: 标准差
    """
    mean = np.mean(data, axis=(0, 1))  # 沿着顶点和时间步计算平均值
    std_dev = np.std(data, axis=(0, 1))  # 沿着顶点和时间步计算标准差
    return mean, std_dev



def main():
    filename = 'data\\myTest_PBD\\sphere\\forunity\\positions1.txt'
    nums = 20  # 顶点的个数
    steps = 1001  # 时间步的数量
    dt = 0.0025  # 时间间隔

    # 读取顶点数据
    positions = read_vertices(filename, nums, steps)
    # 计算速度
    velocities = calculate_velocity(positions, dt)
    # 计算加速度
    accelerations = calculate_acceleration(velocities, dt)

    print(positions.shape)
    print(positions)
    # 计算速度的平均值和标准差
    #v_mean, v_std = compute_stats(velocities)
    v_mean = np.mean(velocities, axis=(0, 1))
    # 计算加速度的平均值和标准差
    a_mean, a_std = compute_stats(accelerations)

    print("Velocity Mean:", v_mean)
    #print("Velocity Standard Deviation:", v_std)
    print("Acceleration Mean:", a_mean)
    #print("Acceleration Standard Deviation:", a_std)

#     # 假设 data_str 是一个字符串，其中包含所有的位置数据，每行一个坐标对
#     data_str = """
#     0.0024427 0.0023383
# -0.00018474 -0.0004427
# 0.00096917 -0.00055643
#     """
#
#     # 将字符串数据转换为 Numpy 数组
#     data_lines = data_str.strip().split("\n")
#     positions = np.array([list(map(float, line.split())) for line in data_lines])
#
#     # 计算速度，dt 默认为 1，如果有具体的时间间隔，请替换这个值
#     dt = 0.0025
#     velocities = np.diff(positions, axis=0) / dt
#
#     print(velocities)
#     # 计算加速度
#     accelerations = np.diff(velocities, axis=0) / dt
#     print(accelerations)
#
#     # 计算统计量
#     velocity_mean = np.mean(velocities, axis=0)
#     velocity_std = np.std(velocities, axis=0)
#     acceleration_mean = np.mean(accelerations, axis=0)
#     acceleration_std = np.std(accelerations, axis=0)
#
#     print("Velocity Mean:", velocity_mean)
#     print("Velocity Standard Deviation:", velocity_std)
#     print("Acceleration Mean:", acceleration_mean)
#     print("Acceleration Standard Deviation:", acceleration_std)


if __name__ == '__main__':
    main()
