import tensorflow as tf
from reading_utils import parse_serialized_simulation_example
import numpy as np
import os
import json

def _read_metadata(data_path):
    with open(os.path.join(data_path, 'metadata.json'), 'rt') as fp:
        return json.loads(fp.read())
#metadata = _read_metadata('data\\myTest_PBD\\sphere')
metadata = _read_metadata('data\\myTest_PBD\\dannang\\simple')

def read_tfrecord_file(tfrecord_filename):
    """读取并解析 tfrecord 文件中的数据。
    Args:
      tfrecord_filename: tfrecord 文件的路径。
    Returns:
      dataset: 处理后的数据集。
    """
    # 创建一个 tfrecord 文件的 dataset
    raw_dataset = tf.data.TFRecordDataset(tfrecord_filename)

    # 定义解析操作
    def _parse_function(proto):
        # 使用 parse_serialized_simulation_example 函数来解析
        return parse_serialized_simulation_example(proto, metadata)

    # 应用解析函数到数据集中的每一个元素
    parsed_dataset = raw_dataset.map(_parse_function)

    return parsed_dataset

tf.compat.v1.enable_eager_execution()
# 示例使用
#tfrecord_path = 'data\\myTest_PBD\\sphere\\test.tfrecord'  # 替换为你的 tfrecord 文件路径
tfrecord_path = 'data\\myTest_PBD\\dannang\\simple\\train.tfrecord'  # 替换为你的 tfrecord 文件路径
dataset = read_tfrecord_file(tfrecord_path)

x = 0
# 遍历数据集的每个元素并打印（或进行其他处理）
for context, features in dataset.take(1):
     print(features['particle_type'])
     #print("Features:", features)

def calculate_velocity(positions, dt):
    velocities = np.diff(positions, axis=1) / dt
    return velocities
def calculate_acceleration(velocities, dt):
    accelerations = np.diff(velocities, axis=1) / dt
    return accelerations
def compute_stats(data):
    mean = np.mean(data, axis=(0, 1))  # 沿着顶点和时间步计算平均值
    std_dev = np.std(data, axis=(0, 1))  # 沿着顶点和时间步计算标准差
    return mean, std_dev

# allvel = []
# allacc = []
# allvstds = []
# allastds = []
#
# dt = 1
# for context, features in dataset.take(1):
#     x += 1
#     #print("Features:", features['position'])
#     position_data = features['position'].numpy()
#     # 计算速度
#
#     # velocities = calculate_velocity(position_data, dt)
#     velocities = np.diff(position_data, axis=0) / dt
#     # 计算加速度
#     #print(position_data.shape)
#     #accelerations = calculate_acceleration(velocities, dt)
#     accelerations = np.diff(velocities, axis=0) / dt
#
#     # print(position_data[0])
#     # print(position_data[1])
#     # print(velocities[0])
#     v_mean = np.mean(velocities, axis=(0, 1))
#     a_mean = np.mean(accelerations, axis=(0, 1))
#     v_std = np.std(velocities, axis=(0, 1))
#     a_std = np.std(accelerations, axis=(0, 1))
#     allvel.append(v_mean)
#     allacc.append(a_mean)
#     allvstds.append(v_std)
#     allastds.append(a_std)
#
# allvmean = np.mean(allvel, axis=(0))
# allvstd = np.mean(allvstds, axis=(0))
# allamean = np.mean(allacc, axis=(0))
# allastd = np.mean(allastds, axis=(0))
# print(allvmean)
# print(allvstd)
# print(allamean)
# print(allastd)
#[ 9.1203765e-06 -2.5778753e-04]
# [0.00138576 0.00126594]
# [-6.2682544e-09  8.7618545e-08]
# [6.412816e-05 7.410488e-05]

print(x) # x表示数据集中有x个sequence_length时间步的序列

# with open('data\\myTest_PBD\\sphere\\forunity\\positions1.txt', 'w') as file:
#     # 遍历数据集中的每个元素
#     for context, features in dataset.take(2):
#         x += 1
#
#         if (x == 1):
#             # 从特征中获取位置数据
#             print("Features:", features['position'])
#             position_data = features['position'].numpy()
#
#             # 使用 numpy.savetxt 写入数据到文件，每行一个坐标
#             np.savetxt(file, position_data.reshape(-1, position_data.shape[-1]), fmt='%.6f')



